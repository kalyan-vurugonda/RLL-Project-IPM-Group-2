import { Policye } from './policye';

describe('Policye', () => {
  it('should create an instance', () => {
    expect(new Policye()).toBeTruthy();
  });
});
