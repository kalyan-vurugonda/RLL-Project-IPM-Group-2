import { Unknownquery } from './unknownquery';

describe('Unknownquery', () => {
  it('should create an instance', () => {
    expect(new Unknownquery()).toBeTruthy();
  });
});
