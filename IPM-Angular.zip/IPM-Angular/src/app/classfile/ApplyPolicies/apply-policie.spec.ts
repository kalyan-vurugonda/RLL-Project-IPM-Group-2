import { ApplyPolicie } from './apply-policie';

describe('ApplyPolicie', () => {
  it('should create an instance', () => {
    expect(new ApplyPolicie()).toBeTruthy();
  });
});
