export class Policye {

    pid!: number;
    policyPrice!: string;
    policyname!: string;

    policycatagory!: string;
    applied!: boolean; // Add this line to include the 'applied' property

    addDateOfPolicy!: string
}