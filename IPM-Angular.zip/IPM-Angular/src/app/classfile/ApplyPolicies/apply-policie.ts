export class ApplyPolicie {


       appid!: number
       policyPrice!: string
       policyCatagory!: string
       policyName!: string;
       policyapplydate!: string
       status!: string;
       customername!: string
       customeremail!: string

}